# DJJCM – Après-Ski Landing Page

## Estructura del repositorio

```
djjcm-apresski/
├── index.html
├── style.css
├── fotos/          ← sube aquí tus fotos (jpg/jpeg/webp)
│   ├── foto1.jpg
│   ├── foto2.jpg
│   └── ...
└── videos/         ← sube aquí tus vídeos (mp4)
    ├── video1.mp4
    └── video2.mp4
```

## Cómo subir a GitHub Pages

1. Crea un repo nuevo llamado `djjcm-apresski` en GitHub
2. Sube todos los archivos (index.html, style.css, carpetas fotos/ y videos/)
3. Ve a Settings → Pages → Source: Deploy from branch `main` / folder `/root`
4. URL pública: `https://djjcm09.github.io/djjcm-apresski`

## Añadir tus fotos

En index.html, busca los bloques `.gallery-item` y reemplaza:
```html
<div class="gallery-placeholder">...</div>
```
por:
```html
<img src="fotos/TU-FOTO.jpg" alt="Après-Ski DJ Carlos">
```

---

## Texto de presentación para agencias (Deutsch)

---

**Betreff: Après-Ski DJ – Buchungsanfrage Wintersaison 2025/26**

Guten Tag,

mein Name ist Carlos Martinez, professioneller DJ aus Nürnberg mit langjähriger Erfahrung in der Après-Ski-Szene der österreichischen Alpen.

Ich biete:
- **Open Format** – von Après-Ski Classics über Commercial House bis Party Anthems
- **Mikrofon & Moderation** auf Deutsch, Englisch und Spanisch
- **Crowd Interaction** – ich lese die Stimmung und bringe das Publikum mit
- **Komplettes Eigenequipment** – PA-System, Lichtanlage, Mikrofone, Nebelmaschine, kein Verleih nötig
- **Flexible Buchung** – Residency für die gesamte Saison oder Einzelauftritte

Verfügbar: November 2025 bis Ende März 2026
Einsatzgebiet: Österreich, Deutschland (Bayern/Allgäu), Schweiz

Mein Portfolio: https://djjcm09.github.io/djjcm-apresski

Ich freue mich auf Ihre Anfrage und stehe für ein persönliches Gespräch gerne zur Verfügung.

Mit freundlichen Grüßen,
Carlos Martinez – DJJCM
📱 +49 152 52822834
📧 jcmartinez7109@gmail.com

---
